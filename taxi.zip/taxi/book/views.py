from django.shortcuts import render,redirect
from . models import Book,Register


# Create your views here.
def home(request):
    return render(request,'home.html')
def book(request):
    if request.method=='POST':
        pickup =request.POST['pickup']
        destination =request.POST["destination"]
        phone=request.POST["phone"]
        datetime=request.POST["datetime"]
        mode=request.POST["mode"]

        ins=Book(pickup=pickup,destination=destination,phone=phone,datetime=datetime,mode=mode)
        ins.save()
        return render(request,'thanks.html')

    return render(request,'book.html')

def thanks(request):
    return render(request,'thanks.html')

def drive(request):
    if request.method=='POST':
        name =request.POST['name']
        email =request.POST["email"]
        phone=request.POST["phone"]
        place=request.POST["place"]
        mode=request.POST["mode"]

        ins=Register(name=name,email=email,phone=phone,place=place,mode=mode)
        ins.save()
        return render(request,'thank.html')

    return render(request,'drivewithus.html')