from django.db import models

# Create your models here.
class Book(models.Model):
    pickup = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    phone = models.CharField(max_length=10)
    datetime = models.CharField(max_length=100)
    mode = models.CharField(max_length=100)

class Register(models.Model):
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=10)
    place = models.CharField(max_length=100)
    mode = models.CharField(max_length=100)
