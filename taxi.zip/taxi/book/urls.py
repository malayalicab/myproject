from django.urls import path
from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path('booknow',views.book,name='book'),
    path('thanks',views.thanks,name='thanks'),
    path('drivewithus',views.drive,name='drive')
]